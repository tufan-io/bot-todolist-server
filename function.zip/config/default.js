module.exports = {
  bucket: 'tufan-exchange',
  key: 'apiLambda/appconfig.json'
}